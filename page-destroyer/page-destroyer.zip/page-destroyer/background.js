chrome.action.onClicked.addListener(async (tab) => {
  if (!tab || tab.id == null) return;
  const url = tab.url || "";
  if (url && !/^(https?|file):/i.test(url)) {
    chrome.action.setBadgeText({ tabId: tab.id, text: "✕" });
    chrome.action.setBadgeBackgroundColor({ tabId: tab.id, color: "#b91c1c" });
    setTimeout(() => chrome.action.setBadgeText({ tabId: tab.id, text: "" }), 1500);
    return;
  }
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["destroyer.js"]
    });
  } catch (err) {
    console.warn("Page Destroyer could not run on this page:", err);
  }
});
